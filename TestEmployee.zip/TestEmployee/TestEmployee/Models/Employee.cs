﻿using System.ComponentModel.DataAnnotations;

namespace TestEmployee.Models
{
    public class Employee
    {
        [Key]
        public int EmpID { get; set; }

        [Required, StringLength(100)]
        public string? FirstName { get; set; }


        [Required, StringLength(100)]
        public string? LastName { get; set; }

        [Required, EmailAddress,StringLength(150)]
        public string? EmailAddress { get; set; }

        [Required, DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }

        [Required, StringLength(100)]
        public string? Position { get; set; }
        public decimal Salary { get; set; }
    }
}
