﻿using Microsoft.EntityFrameworkCore;
using TestEmployee.Models;

namespace TestEmployee.DAL
{
    public class EmployeeContext : DbContext
    {
        public EmployeeContext (DbContextOptions<EmployeeContext> options) :base (options) 
        { 
        }

        public DbSet<Employee> TestEmploy { get; set; }
    }
}
